package com.example.faltu;

import android.app.Activity;
import android.os.Bundle;

public class Right extends Activity{
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.right);
		
	}
	

}
